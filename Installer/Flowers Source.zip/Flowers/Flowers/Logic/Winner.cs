﻿
namespace Flowers {
	public struct Winner {
		public int[] winningIndexes;
		public Flower.FlowerType winningType;
	}
}
